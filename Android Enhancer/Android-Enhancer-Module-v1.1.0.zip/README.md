# Android Enhancer Module 🚀
Module variant of Android Enhancer that works on both Magisk and KSU.

## Instructions 📜
- Flash & reboot.
- Check for logs in Internal Storage / Android.
- Forget that you installed it in first place if you liked it & you are seeing a improvement.
