SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=true
LATESTARTSERVICE=true

REPLACE="
"
print_modname() {
  ui_print "  𝟵𝗭 𝗣𝗲𝗿𝗳𝗫 "
sleep 2
  ui_print " 𝗩𝗲𝗿𝘀𝗶𝗼𝗻 : 𝙿𝚎𝚛𝚏𝚇++"
}
on_install() {
  ui_print " 𝗕𝘂𝗶𝗹𝗱 𝗗𝗮𝘁𝗲 : 3 - 12 - 2023"
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
  set_permissions
    sleep 1
    ui_print "⤚⤚⤚⤚⤚⤚⤚✭⤙⤙⤙⤙⤙⤙⤙"
    ui_print " ◨ Getting your device info.. ◧"
    sleep 1
    ui_print ""
    sleep 0.5
    ui_print " ⊳ Android version : $(getprop ro.build.version.release)"
    sleep 0.5
  ui_print " ⊳ Brand : $(getprop ro.product.system.manufacturer)"
  sleep 0.5
  ui_print " ⊳ Cpu : $(getprop ro.hardware)"
  sleep 0.5
  ui_print " ⊳ Model : $(getprop ro.product.model)"
  sleep 0.5
  ui_print " ⊳ Kernel : $(uname -r)"
  sleep 0.5
  ui_print " ⊳ Ram : $(free | grep Mem |  awk '{print $2}')"
  sleep 1
  ui_print "⤚⤚⤚⤚⤚⤚⤚✭⤙⤙⤙⤙⤙⤙⤙"
  sleep 1
  ui_print " 〄 ░ 𝗗𝗼𝗻𝗲, 𝗣𝗹𝗲𝗮𝘀𝗲 𝗿𝗲𝗯𝗼𝗼𝘁 𝘆𝗼𝘂𝗿 𝗱𝗲𝘃𝗶𝗰𝗲 (⁠ ⁠╹⁠▽⁠╹⁠ ⁠) ░ 〄 "
sleep 2
  ui_print ""
}
set_permissions() {
  set_perm_recursive $MODPATH 0 0 0755 0755
  set_perm $MODPATH/system/bin/cleancache 0 0 0755 0755
  set_perm $MODPATH/system/etc/init.d/ 0 0 0755 0755
}

# 
