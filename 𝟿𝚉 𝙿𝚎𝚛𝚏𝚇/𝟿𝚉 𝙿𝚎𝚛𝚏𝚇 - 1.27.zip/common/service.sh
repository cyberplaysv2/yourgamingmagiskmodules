MODDIR=${0%/*}
while [[ -z $(getprop sys.boot_completed) ]]; do sleep 5; done
busybox=$(find /data/adb/ -type f -name busybox | head -n 1)
$busybox swapoff /dev/block/zram0
echo "1" > /sys/block/zram0/reset
echo "4294967296" > /sys/block/zram0/disksize
$busybox mkswap /dev/block/zram0
$busybox swapon /dev/block/zram0
iptables -t nat -A OUTPUT -p tcp --dport 53 -j DNAT --to-destination 8.8.8.8:53
iptables -t nat -A OUTPUT -p udp --dport 53 -j DNAT --to-destination 1.1.1.1:53
iptables -t nat -I OUTPUT -p tcp --dport 53 -j DNAT --to-destination 8.8.8.8:53
iptables -t nat -I OUTPUT -p udp --dport 53 -j DNAT --to-destination 1.1.1.1:53
echo '100' > /proc/sys/vm/swappiness
echo '0' > /proc/sys/vm/laptop_mode
echo '0' > /proc/sys/vm/oom_kill_allocating_task
echo '1' > /proc/sys/vm/panic_on_oom
echo '15' > /proc/sys/vm/dirty_background_ratio
echo '30' > /proc/sys/vm/dirty_ratio
echo '500' > /proc/sys/vm/vfs_cache_pressure
echo "0 0 0 0" > /proc/sys/kernel/printk
echo "0" > /proc/sys/kernel/panic
echo "0" > /proc/sys/kernel/panic_on_oops
echo "0" > /proc/sys/kernel/perf_cpu_time_max_percent
echo "0" > /proc/sys/kernel/sched_tunable_scaling
echo "1" > /sys/devices/system/cpu/cpu0/cpufreq/busfreq_static
echo "1" > /sys/devices/system/cpu/cpufreq/smartass/ramp_up_step
echo "1" > /sys/devices/system/cpu/cpufreq/smartass/ramp_down_step
echo "1000" > /sys/devices/system/cpu/cpufreq/smartass/up_rate_us
echo "10000" > /sys/devices/system/cpu/cpufreq/smartass/down_rate_us
echo "1600000" > /sys/devices/system/cpu/cpufreq/smartass/awake_ideal_freq
echo "400000" > /sys/devices/system/cpu/cpufreq/smartass/sleep_ideal_freq
echo "1600000" > /sys/devices/system/cpu/cpufreq/smartass/sleep_wakeup_freq
echo "100" > /sys/devices/system/cpu/cpufreq/smartass/max_cpu_load
echo "55" > /sys/devices/system/cpu/cpufreq/smartass/min_cpu_load
echo "0" > /sys/devices/system/cpu/sched_mc_power_savings
echo "1 1 1" > /sys/class/misc/gpu_control/gpu_staycount
echo '0' > "/sys/module/msm_perfmon/parameters/touch_boost_enable"
echo '0' > "/sys/module/msm_perfmon/parameters/touch_boost_freq"
echo '0' > "/sys/module/msm_performance/parameters/touchboost"
echo '0' > "/sys/power/pnpmgr/touch_boost"
echo "0" > /proc/touchpanel/oppo_tp_limit_enable
echo "0" > /proc/touchpanel/oplus_tp_limit_enable
echo '14005' > /sys/class/touch/switch/set_touchscreen;
for tcp in /proc/sys/net/ipv4/
do
write "${tcp}ip_no_pmtu_disc" "0"
write "${tcp}tcp_ecn" "2"
write "${tcp}tcp_timestamps" "0"
write "${tcp}route.flush" "1"
write "${tcp}tcp_rfc1337" "1"
write "${tcp}tcp_tw_reuse" "1"
write "${tcp}tcp_sack" "1"
write "${tcp}tcp_fack" "1"
write "${tcp}tcp_fastopen" "3"
write "${tcp}tcp_tw_recycle" "1"
write "${tcp}tcp_no_metrics_save" "0"
write "${tcp}tcp_syncookies" "0"
write "${tcp}tcp_window_scaling" "1"
write "${tcp}tcp_keepalive_probes" "10"
write "${tcp}tcp_keepalive_intvl" "30"
write "${tcp}tcp_fin_timeout" "30"
write "${tcp}tcp_low_latency" "1"
write "${tcp}tcp_congestion_control" "cubic"
done
echo 0 > /proc/sys/net/ipv4/conf/default/secure_redirects
echo 0 > /proc/sys/net/ipv4/conf/default/accept_redirects
echo 0 > /proc/sys/net/ipv4/conf/default/accept_source_route
echo 0 > /proc/sys/net/ipv4/conf/all/secure_redirects
echo 0 > /proc/sys/net/ipv4/conf/all/accept_redirects
echo 0 > /proc/sys/net/ipv4/conf/all/accept_source_route
echo 0 > /proc/sys/net/ipv4/ip_forward
echo 0 > /proc/sys/net/ipv4/ip_dynaddr
echo 0 > /proc/sys/net/ipv4/ip_no_pmtu_disc
echo 0 > /proc/sys/net/ipv4/tcp_ecn
echo 0 > /proc/sys/net/ipv4/tcp_timestamps
echo 1 > /proc/sys/net/ipv4/tcp_tw_reuse
echo 1 > /proc/sys/net/ipv4/tcp_fack
echo 1 > /proc/sys/net/ipv4/tcp_sack
echo 1 > /proc/sys/net/ipv4/tcp_dsack
echo 1 > /proc/sys/net/ipv4/tcp_rfc1337
echo 1 > /proc/sys/net/ipv4/tcp_tw_recycle
echo 1 > /proc/sys/net/ipv4/tcp_window_scaling
echo 1 > /proc/sys/net/ipv4/tcp_moderate_rcvbuf
echo 1 > /proc/sys/net/ipv4/tcp_no_metrics_save
echo 2 > /proc/sys/net/ipv4/tcp_synack_retries
echo 2 > /proc/sys/net/ipv4/tcp_syn_retries
echo 5 > /proc/sys/net/ipv4/tcp_keepalive_probes
echo 30 > /proc/sys/net/ipv4/tcp_keepalive_intvl
echo 30 > /proc/sys/net/ipv4/tcp_fin_timeout
echo 1800 > /proc/sys/net/ipv4/tcp_keepalive_time
echo 5505024 > /proc/sys/net/core/rmem_max
echo 5505024 > /proc/sys/net/core/wmem_max
echo 5505024 > /proc/sys/net/core/rmem_default
echo 5505024 > /proc/sys/net/core/wmem_default
echo 0 >/sys/devices/soc/qpnp-flash-led-25/leds/led:torch_1/max_brightness;
chmod 0644 /sys/devices/system/cpu/cpufreq/policy0/scaling_governor
chmod 0644 /sys/devices/system/cpu/cpufreq/policy6/scaling_governor
restorecon -R /sys/devices/system/cpu
if [ -d /proc/sys/kernel ]; then
lock_val "0" /proc/sys/kernel/compat-log
lock_val "1" /proc/sys/kernel/panic
lock_val "1" /proc/sys/kernel/panic_on_oops
lock_val "0" /proc/sys/kernel/softlockup_panic
lock_val "100" /proc/sys/kernel/perf_cpu_time_max_percent
lock_val "0" /proc/sys/kernel/nmi_watchdog
lock_val "5" /proc/sys/kernel/sched_walt_init_task_load_pct
lock_val "0" /proc/sys/kernel/sched_tunable_scaling
lock_val "0" /proc/sys/kernel/sched_child_runs_first
lock_val "1000000000" /proc/sys/kernel/max_lock_depth
lock_val "0" /proc/sys/kernel/sched_sync_hint_enable
lock_val "0" /proc/sys/kernel/sched_initial_task_util
lock_val "1" /proc/sys/kernel/sched_cstate_aware
lock_val "0" /proc/sys/kernel/sched_migration_cost_ns
lock_val "0" /proc/sys/kernel/sched_shares_window_ns
lock_val "1" /proc/sys/kernel/sched_time_avg_ms
lock_val "1" /proc/sys/kernel/sched_nr_migrate
lock_val "100000" /proc/sys/kernel/sched_min_granularity_ns
lock_val "1000000" /proc/sys/kernel/sched_latency_ns
lock_val "1000000000" /proc/sys/kernel/sched_wakeup_granularity_ns
fi
rm -rf /data/data/com.rahul.videoderbeta/shared_prefs/com.google.android.gms.analytics.prefs.xml
rm -rf /data/data/com.google.android.deskclock/shared_prefs/com.google.android.gms.analytics.prefs.xml
rm -rf /data/data/com.google.android.play.games/shared_prefs/com.google.android.gms.analytics.prefs.xml
rm -rf /data/data/com.digibites.accubattery/shared_prefs/com.google.android.gms.analytics.prefs.xml
rm -rf /data/data/com.vanced.android.youtube/shared_prefs/com.google.android.gms.measurement.prefs.xml
rm -rf /data/data/com.paget96.lsandroid/shared_prefs/com.google.android.gms.measurement.prefs.xml
rm -rf /data/data/com.samsung.android.mobileservice/shared_prefs/com.google.android.gms.measurement.prefs.xml
rm -rf /data/data/droom.sleepIfUCan/shared_prefs/com.google.android.gms.measurement.prefs.xml
rm -f /data/data/com.rahul.videoderbeta/shared_prefs/com.google.android.gms.measurement.prefs.xml
rm -f /data/data/com.sec.android.app.samsungapps/shared_prefs/com.google.android.gms.measurement.prefs.xml
rm -f /data/data/com.google.android.play.games/shared_prefs/com.google.android.gms.measurement.prefs.xml
rm -f /data/data/com.digibites.accubattery/shared_prefs/com.google.android.gms.measurement.prefs.xml
rm -f /data/data/com.sec.android.daemonapp/shared_prefs/com.google.android.gms.measurement.prefs.xml
rm -f /data/data/in.android.vcredit/shared_prefs/com.google.android.gms.measurement.prefs.xml
rm -f /data/data/com.rubenmayayo.reddit/shared_prefs/com.google.android.gms.measurement.prefs.xml
rm -f /data/data/com.osp.app.signin/shared_prefs/com.google.android.gms.measurement.prefs.xml
rm -f /data/data/com.samsung.android.rubin.app/shared_prefs/com.google.android.gms.measurement.prefs.xml
rm -f /data/data/com.google.android.googlequicksearchbox/shared_prefs/com.google.android.gms.measurement.prefs.xml
rm -f /data/data/com.core.lntmobile/shared_prefs/com.google.android.gms.measurement.prefs.xml
rm -f /data/data/com.samsung.android.dynamiclock/shared_prefs/com.google.android.gms.measurement.prefs.xml
rm -f /data/data/com.paget96.netspeedindicator/shared_prefs/com.google.android.gms.measurement.prefs.xml
rm -f /data/data/com.paget96.lsandroid/shared_prefs/com.google.firebase.crashlytics.xml
rm -f /data/data/droom.sleepIfUCan/shared_prefs/com.google.firebase.remoteconfig_legacy_settings.xml
rm -f /data/data/droom.sleepIfUCan/shared_prefs/com.google.firebase.crashlytics.xml
rm -f /data/data/droom.sleepIfUCan/shared_prefs/frc_1:633738944520:android:716b5964e99d2c3d_firebase_settings.xml
rm -f /data/data/com.camerasideas.instashot/shared_prefs/frc_1:1000386510336:android:ab5973db7e7e86ed_firebase_settings.xml
rm -f /data/data/com.touchtype.swiftkey/shared_prefs/com.google.firebase.messaging.xml
rm -f /data/data/com.google.android.play.games/shared_prefs/com.google.firebase.common.prefs:W0RFRkFVTFRd+MTo1OTM5NTA2MDI0MTg6YW5kcm9pZDpjNGRhMWMwNTdjZjU3YmE4.xml
rm -f /data/data/org.telegram.messenger/shared_prefs/com.google.firebase.remoteconfig_legacy_settings.xml
rm -f /data/data/org.telegram.messenger/shared_prefs/frc_1:760348033671:android:f6afd7b67eae3860_firebase_settings.xml
rm -f /data/data/in.android.vcredit/shared_prefs/com.google.firebase.remoteconfig_legacy_settings.xml
rm -f /data/data/in.android.vcredit/shared_prefs/frc_1:1002943954979:android:bfc8b0f2ed5f47a0_firebase_settings.xml
rm -f /data/data/com.rubenmayayo.reddit/shared_prefs/frc_1:275128417090:android:3dc63557758b5b0f_firebase_settings.xml
rm -f /data/data/com.rubenmayayo.reddit/shared_prefs/com.google.firebase.remoteconfig_legacy_settings.xml
rm -f /data/data/photo.editor.photoeditor.photoeditorpro/shared_prefs/frc_1:757324348735:android:caaddb32e54f9271_firebase_settings.xml
rm -f /data/data/wifisecurity.ufovpn.android/shared_prefs/frc_1:76973129151:android:ab00156b263ee3195ef50a_firebase_settings.xml
rm -f /data/data/com.paget96.netspeedindicator/shared_prefs/com.google.firebase.crashlytics.xml
rm -f /data/user_de/0/com.samsung.android.fmm/shared_prefs/com.google.firebase.messaging.xml
rm -f /data/data/com.paget96.lsandroid/shared_prefs/com.google.firebase.crashlytics.xml
rm -f /data/data/droom.sleepIfUCan/shared_prefs/com.google.firebase.remoteconfig_legacy_settings.xml
rm -f /data/data/droom.sleepIfUCan/shared_prefs/com.google.firebase.crashlytics.xml
rm -f /data/data/com.touchtype.swiftkey/shared_prefs/com.google.firebase.messaging.xml
rm -f /data/data/com.google.android.play.games/shared_prefs/com.google.firebase.common.prefs:W0RFRkFVTFRd+MTo1OTM5NTA2MDI0MTg6YW5kcm9pZDpjNGRhMWMwNTdjZjU3YmE4.xml
rm -f /data/data/org.telegram.messenger/shared_prefs/com.google.firebase.remoteconfig_legacy_settings.xml
rm -f /data/data/in.android.vcredit/shared_prefs/com.google.firebase.remoteconfig_legacy_settings.xml
rm -f /data/data/com.rubenmayayo.reddit/shared_prefs/com.google.firebase.remoteconfig_legacy_settings.xml
rm -f /data/data/com.paget96.netspeedindicator/shared_prefs/com.google.firebase.crashlytics.xml
rm -f /data/user_de/0/com.samsung.android.fmm/shared_prefs/com.google.firebase.messaging.xml
rm -f /data/data/com.touchtype.swiftkey/shared_prefs/telemetry_service_key.xml
rm -f /data/data/com.samsung.android.biometrics.app.setting/shared_prefs/com.samsung.android.biometrics.app.setting_preferences.xml
rm -f /data/data/com.samsung.android.tadownloader/shared_prefs/tad_biometrics_info.xml
rm -f /data/data/com.google.android.gms/shared_prefs/GnssmetricsPH.xml
rm -f /data/data/com.google.android.gms/shared_prefs/com.google.android.metrics.xml
rm -f /data/data/com.paget96.lsandroid/shared_prefs/com.google.firebase.crashlytics.xml
rm -f /data/data/droom.sleepIfUCan/shared_prefs/com.google.firebase.crashlytics.xml
rm -f /data/data/com.rahul.videoderbeta/shared_prefs/com.crashlytics.sdk.android:answers:settings.xml
rm -f /data/data/com.rahul.videoderbeta/shared_prefs/com.crashlytics.prefs.xml
rm -f /data/data/com.samsung.android.game.gamehome/shared_prefs/com.crashlytics.sdk.android:answers:settings.xml
rm -f /data/data/com.samsung.android.game.gamehome/shared_prefs/com.crashlytics.prefs.xml
rm -f /data/data/in.android.vcredit/shared_prefs/com.crashlytics.sdk.android:answers:settings.xml
rm -f /data/data/in.android.vcredit/shared_prefs/com.crashlytics.prefs.xml
rm -f /data/data/com.opera.max.oem/shared_prefs/com.crashlytics.sdk.android.crashlytics-core:com.crashlytics.android.core.CrashlyticsCore.xml
rm -f /data/data/com.opera.max.oem/shared_prefs/com.crashlytics.sdk.android:answers:settings.xml
rm -f /data/data/com.opera.max.oem/shared_prefs/com.crashlytics.prefs.xml
rm -f /data/data/com.rubenmayayo.reddit/shared_prefs/com.crashlytics.sdk.android:answers:settings.xml
rm -f /data/data/com.rubenmayayo.reddit/shared_prefs/com.crashlytics.prefs.xml
rm -f /data/data/photo.editor.photoeditor.photoeditorpro/shared_prefs/com.crashlytics.sdk.android:answers:settings.xml
rm -f /data/data/photo.editor.photoeditor.photoeditorpro/shared_prefs/com.crashlytics.prefs.xml
rm -f /data/data/com.hiya.star/shared_prefs/com.crashlytics.sdk.android:answers:settings.xml
rm -f /data/data/com.hiya.star/shared_prefs/com.crashlytics.prefs.xml
rm -f /data/data/wifisecurity.ufovpn.android/shared_prefs/com.crashlytics.sdk.android:answers:settings.xml
rm -f /data/data/wifisecurity.ufovpn.android/shared_prefs/com.crashlytics.prefs.xml
rm -f /data/data/ir.stsepehr.hamrahcard/shared_prefs/com.crashlytics.sdk.android:answers:settings.xml
rm -f /data/data/ir.stsepehr.hamrahcard/shared_prefs/com.crashlytics.prefs.xml
rm -f /data/data/com.intsig.camscanner/shared_prefs/com.crashlytics.sdk.android:answers:settings.xml
rm -f /data/data/com.intsig.camscanner/shared_prefs/com.crashlytics.prefs.xml
rm -f /data/data/com.paget96.netspeedindicator/shared_prefs/com.google.firebase.crashlytics.xml
rm -f /data/data/com.samsung.android.mobileservice/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/data/com.samsung.android.app.appsedge/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/data/com.samsung.android.themestore/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/data/com.sec.android.app.quicktool/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/data/com.samsung.android.app.contacts/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/data/com.samsung.android.calendar/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/data/com.sec.android.app.samsungapps/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/data/com.samsung.android.app.routines/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/data/com.samsung.android.net.wifi.wifiguider/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/data/com.samsung.android.messaging/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/data/com.samsung.android.app.galaxyfinder/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/data/com.samsung.android.dialer/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/data/com.sec.android.daemonapp/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/data/com.samsung.android.app.social/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/data/com.samsung.android.applock/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/data/com.samsung.android.app.taskedge/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/data/com.samsung.android.mdecservice/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/data/com.samsung.android.mdx.quickboard/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/data/com.samsung.android.app.aodservice/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/data/com.samsung.storyservice/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/data/com.samsung.android.dqagent/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/data/com.osp.app.signin/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/data/com.samsung.android.rubin.app/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/data/com.samsung.android.rubin.app/shared_prefs/SamsungAnalyticsPrefs_runestone.xml
rm -f /data/data/com.samsung.android.rubin.app/shared_prefs/SamsungAnalyticsPrefs_ad.xml
rm -f /data/data/com.samsung.android.allshare.service.fileshare/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/data/com.sec.android.app.camera/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/data/com.samsung.android.mdx/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/data/com.samsung.android.game.gametools/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/data/com.samsung.android.dynamiclock/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/data/com.samsung.android.app.simplesharing/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/data/com.samsung.android.lool/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/data/com.samsung.android.app.cocktailbarservice/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/data/com.sec.android.app.myfiles/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/data/com.samsung.android.video/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/data/com.sec.android.app.launcher/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/user_de/0/com.samsung.android.fmm/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/user_de/0/com.android.systemui/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/user_de/0/com.samsung.android.incallui/shared_prefs/SamsungAnalyticsPrefs.xml
rm -f /data/data/com.netflix.mediaclient/shared_prefs/com.netflix.mediaclient.client_cast_analytics_data.xml
rm -f /data/data/com.instagram.android/shared_prefs/com.facebook.analytics.appstatelogger.AppStateBroadcastReceiver.xml
rm -f /data/data/com.instagram.android/shared_prefs/analyticsprefs.xml
rm -f /data/data/com.instagram.android/shared_prefs/rti.mqtt.analytics.xml
echo Disable CABC Mode for best experience
echo 0 > /sys/kernel/oppo_display/cabc
echo 0 > /sys/kernel/oppo_display/LCM_CABC
echo 0 > /sys/kernel/ccci/debug
echo Add some games to sport mode
echo -e "com.mobile.legends\ncom.tencent.ig\ncom.miHoYo.GenshinImpact\ncom.tencent.tmgp.pubgmhd\ncom.dts.freefireth\ncom.dts.freefiremax\njp.konami.pesam\ncom.pubg.newstate\ncom.garena.game.codm\ncom.pubg.imobile\ncom.ea.gp.apexlegendsmobilefps\ncom.riotgames.league.wildrift\ncom.tencent.tmgp.sgame\ncom.tencent.iglite\ncom.vng.pubgmobile\ncom.miHoYo.bh3oversea\ncom.pubg.krmobile\ncom.rekoo.pubgm\ncom.activision.callofduty.shooter\ncom.garena.game.bc\ncom.garena.game.codm\ncom.tencent.ig\ncom.miHoYo.GenshinImpact\ncom.ea.gp.fifamobile\ncom.netease.newspike\ncom.mobilelegends.hwag\ncom.proximabeta.mf.liteuamo\ncom.rockstargames.gtasa\ncom.rockstargames.gtasa\ncom.proximabeta.mf.liteuamo\ncom.miHoYo.bh3oversea\ncom.supercell.clashofclans\ncom.netease.newspike\n" > /data/vendor/powerhal/smart
busybox killall -9 com.google.android.gms
busybox killall -9 com.google.android.gms.persistent
busybox killall -9 com.google.process.gapps
busybox killall -9 com.google.android.gsf
busybox killall -9 com.google.android.gsf.persistent
su -c pm disable com.google.android.gms/.chimera.GmsIntentOperationService
su -c "pm disable com.google.android.gms/.ads.settings.AdsSettingsActivity"
su -c "pm disable com.google.android.gms/com.google.android.location.places.ui.aliaseditor.AliasEditorActivity"
su -c "pm disable com.google.android.gms/com.google.android.location.places.ui.aliaseditor.AliasEditorMapActivity"
su -c "pm disable com.google.android.gms/com.google.android.location.settings.ActivityRecognitionPermissionActivity"
su -c "pm disable com.google.android.gms/com.google.android.location.settings.GoogleLocationSettingsActivity"
su -c "pm disable com.google.android.gms/com.google.android.location.settings.LocationHistorySettingsActivity"
su -c "pm disable com.google.android.gms/com.google.android.location.settings.LocationSettingsCheckerActivity"
su -c "pm disable com.google.android.gms/.usagereporting.settings.UsageReportingActivity"
su -c "pm disable com.google.android.gms/.ads.adinfo.AdvertisingInfoContentProvider"
su -c "pm disable com.google.android.gms/com.google.android.location.reporting.service.ReportingContentProvider"
su -c "pm disable com.google.android.gms/com.google.android.location.internal.LocationContentProvider"
su -c "pm enable com.google.android.gms/.common.stats.net.contentprovider.NetworkUsageContentProvider"
su -c "pm disable com.google.android.gms/com.google.android.gms.ads.config.GServicesChangedReceiver"
su -c "pm disable com.google.android.gms/com.google.android.contextmanager.systemstate.SystemStateReceiver"
su -c "pm disable com.google.android.gms/.ads.jams.SystemEventReceiver"
su -c "pm disable com.google.android.gms/.ads.config.FlagsReceiver"
su -c "pm disable com.google.android.gms/.ads.social.DoritosReceiver"
su -c "pm disable com.google.android.gms/.analytics.AnalyticsReceiver"
su -c "pm disable com.google.android.gms/.analytics.internal.GServicesChangedReceiver"
su -c "pm disable com.google.android.gms/.common.analytics.CoreAnalyticsReceiver"
su -c "pm enable com.google.android.gms/.common.stats.GmsCoreStatsServiceLauncher"
su -c "pm disable com.google.android.gms/com.google.android.location.internal.AnalyticsSamplerReceiver"
su -c "pm disable com.google.android.gms/.checkin.CheckinService\$ActiveReceiver"
su -c "pm disable com.google.android.gms/.checkin.CheckinService\$ClockworkFallbackReceiver"
su -c "pm disable com.google.android.gms/.checkin.CheckinService\$ImposeReceiver"
su -c "pm disable com.google.android.gms/.checkin.CheckinService\$SecretCodeReceiver"
su -c "pm disable com.google.android.gms/.checkin.CheckinService\$TriggerReceiver"
su -c "pm disable com.google.android.gms/.checkin.EventLogService\$Receiver"
su -c "pm disable com.google.android.gms/com.google.android.location.reporting.service.ExternalChangeReceiver"
su -c "pm disable com.google.android.gms/com.google.android.location.reporting.service.GcmRegistrationReceiver"
su -c "pm disable com.google.android.gms/com.google.android.location.copresence.GcmRegistrationReceiver"
su -c "pm disable com.google.android.gms/com.google.android.location.copresence.GservicesBroadcastReceiver"
su -c "pm disable com.google.android.gms/com.google.android.location.internal.LocationProviderEnabler"
su -c "pm disable com.google.android.gms/com.google.android.location.internal.NlpNetworkProviderSettingsUpdateReceiver"
su -c "pm disable com.google.android.gms/com.google.android.location.network.ConfirmAlertActivity\$LocationModeChangingReceiver"
su -c "pm disable com.google.android.gms/com.google.android.location.places.ImplicitSignalsReceiver"
su -c "pm disable com.google.android.gms/com.google.android.libraries.social.mediamonitor.MediaMonitor"
su -c "pm disable com.google.android.gms/.location.copresence.GcmBroadcastReceiver"
su -c "pm disable com.google.android.gms/.location.reporting.service.GcmBroadcastReceiver"
su -c "pm disable com.google.android.gms/.social.location.GservicesBroadcastReceiver"
su -c "pm disable com.google.android.gms/.update.SystemUpdateService\$Receiver"
su -c "pm disable com.google.android.gms/.update.SystemUpdateService\$OtaPolicyReceiver"
su -c "pm disable com.google.android.gms/.update.SystemUpdateService\$SecretCodeReceiver"
su -c "pm disable com.google.android.gms/.update.SystemUpdateService\$ActiveReceiver"
su -c "pm disable com.google.android.gms/com.google.android.contextmanager.service.ContextManagerService"
su -c "pm enable com.google.android.gms/.ads.AdRequestBrokerService"
su -c "pm disable com.google.android.gms/.ads.GservicesValueBrokerService"
su -c "pm disable com.google.android.gms/.ads.identifier.service.AdvertisingIdNotificationService"
su -c "pm enable com.google.android.gms/.ads.identifier.service.AdvertisingIdService"
su -c "pm disable com.google.android.gms/.ads.jams.NegotiationService"
su -c "pm disable com.google.android.gms/.ads.pan.PanService"
su -c "pm disable com.google.android.gms/.ads.social.GcmSchedulerWakeupService"
su -c "pm disable com.google.android.gms/.analytics.AnalyticsService"
su -c "pm disable /.analytics.internal.PlayLogReportingService"
su -c "pm disable com.google.android.gms/.analytics.service.AnalyticsService"
su -c "pm disable com.google.android.gms/.analytics.service.PlayLogMonitorIntervalService"
su -c "pm disable com.google.android.gms/.analytics.service.RefreshEnabledStateService"
su -c "pm disable com.google.android.gms/.auth.be.proximity.authorization.userpresence.UserPresenceService"
su -c "pm disable com.google.android.gms/.common.analytics.CoreAnalyticsIntentService"
su -c "pm enable com.google.android.gms/.common.stats.GmsCoreStatsService"
su -c "pm disable com.google.android.gms/.backup.BackupStatsService"
su -c "pm disable com.google.android.gms/.deviceconnection.service.DeviceConnectionAsyncService"
su -c "pm disable com.google.android.gms/.deviceconnection.service.DeviceConnectionServiceBroker"
su -c "pm disable com.google.android.gms/.wallet.service.analytics.AnalyticsIntentService"
su -c "pm enable com.google.android.gms/.checkin.CheckinService"
su -c "pm enable com.google.android.gms/.checkin.EventLogService"
su -c "pm disable com.google.android.gms/com.google.android.location.internal.AnalyticsUploadIntentService"
su -c "pm disable com.google.android.gms/com.google.android.location.reporting.service.DeleteHistoryService"
su -c "pm disable com.google.android.gms/com.google.android.location.reporting.service.DispatchingService"
su -c "pm disable com.google.android.gms/com.google.android.location.reporting.service.InternalPreferenceServiceDoNotUse"
su -c "pm disable com.google.android.gms/com.google.android.location.reporting.service.LocationHistoryInjectorService"
su -c "pm disable com.google.android.gms/com.google.android.location.reporting.service.ReportingAndroidService"
su -c "pm disable com.google.android.gms/com.google.android.location.reporting.service.ReportingSyncService"
su -c "pm disable com.google.android.gms/com.google.android.location.activity.HardwareArProviderService"
su -c "pm disable com.google.android.gms/com.google.android.location.fused.FusedLocationService"
su -c "pm disable com.google.android.gms/com.google.android.location.fused.service.FusedProviderService"
su -c "pm disable com.google.android.gms/com.google.android.location.geocode.GeocodeService"
su -c "pm disable com.google.android.gms/com.google.android.location.geofencer.service.GeofenceProviderService"
su -c "pm enable com.google.android.gms/com.google.android.location.internal.GoogleLocationManagerService"
su -c "pm disable com.google.android.gms/com.google.android.location.places.PlaylogService"
su -c "pm enable com.google.android.gms/com.google.android.location.places.service.GeoDataService"
su -c "pm enable com.google.android.gms/com.google.android.location.places.service.PlaceDetectionService"
su -c "pm disable com.google.android.gms/com.google.android.libraries.social.mediamonitor.MediaMonitorIntentService"
su -c "pm disable com.google.android.gms/.config.ConfigService"
su -c "pm enable com.google.android.gms/.stats.PlatformStatsCollectorService"
su -c "pm enable com.google.android.gms/.usagereporting.service.UsageReportingService"
su -c "pm enable com.google.android.gms/.update.SystemUpdateService"
su -c "pm enable com.google.android.gms/com.google.android.location.network.ConfirmAlertActivity"
su -c "pm enable com.google.android.gms/com.google.android.location.network.LocationProviderChangeReceiver"
su -c "pm enable com.google.android.gms/com.google.android.location.internal.server.GoogleLocationService"
su -c "pm enable com.google.android.gms/com.google.android.location.internal.PendingIntentCallbackService"
su -c "pm enable com.google.android.gms/com.google.android.location.network.NetworkLocationService"
su -c "pm enable com.google.android.gms/com.google.android.location.util.PreferenceService"
su -c "pm disable com.google.android.gsf/.update.SystemUpdateActivity"
su -c "pm disable com.google.android.gsf/.update.SystemUpdatePanoActivity"
su -c "pm disable com.google.android.gsf/com.google.android.gsf.checkin.CheckinService\$Receiver"
su -c "pm disable com.google.android.gsf/com.google.android.gsf.checkin.CheckinService\$SecretCodeReceiver"
su -c "pm disable com.google.android.gsf/com.google.android.gsf.checkin.CheckinService\$TriggerReceiver"
su -c "pm disable com.google.android.gsf/.checkin.EventLogService\$Receiver"
su -c "pm disable com.google.android.gsf/.update.SystemUpdateService\$Receiver"
su -c "pm disable com.google.android.gsf/.update.SystemUpdateService\$SecretCodeReceiver"
su -c "pm disable com.google.android.gsf/.checkin.CheckinService"
su -c "pm disable com.google.android.gsf/.checkin.EventLogService"
su -c "pm disable com.google.android.gsf/.update.SystemUpdateService"
su -c "pm disable com.google.android.apps.wellbeing/.powerstate.impl.PowerStateJobService"
su -c "pm disable com.google.android.apps.wellbeing/androidx.work.impl.background.systemjob.SystemJobService"
su -c "pm disable com.facebook.katana/com.facebook.analytics.appstatelogger.AppStateIntentService"
su -c "pm disable com.facebook.orca/com.facebook.analytics.apptatelogger.AppStateIntentService"
su -c "pm disable com.facebook.orca/com.facebook.analytics2.Logger.LollipopUploadService"
echo TCP Congestion Control
echo cubic > /proc/sys/net/ipv4/tcp_congestion_control
cat /proc/sys/net/ipv4/tcp_congestion_control
echo Enable TCP low latency
echo 1 > /proc/sys/net/ipv4/tcp_low_latency
echo 0 > /sys/kernel/oppo_display/cabc
echo 0 > /sys/kernel/oppo_display/LCM_CABC
echo "0" > /sys/block/mmcblk0/queue/iostats
echo "0" > /sys/block/mmcblk0rpmb/queue/iostats
echo "0" > /sys/block/mmcblk1/queue/iostats
echo "0" > /sys/block/loop0/queue/iostats
echo "0" > /sys/block/loop1/queue/iostats
echo "0" > /sys/block/loop2/queue/iostats
echo "0" > /sys/block/loop3/queue/iostats
echo "0" > /sys/block/loop4/queue/iostats
echo "0" > /sys/block/loop5/queue/iostats
echo "0" > /sys/block/loop6/queue/iostats
echo "0" > /sys/block/loop7/queue/iostats
echo "0" > /sys/block/loop8/queue/iostats
echo "0" > /sys/block/loop9/queue/iostats
echo "0" > /sys/block/loop10/queue/iostats
echo "0" > /sys/block/loop11/queue/iostats
echo "0" > /sys/block/loop12/queue/iostats
echo "0" > /sys/block/loop13/queue/iostats
echo "0" > /sys/block/loop14/queue/iostats
echo "0" > /sys/block/loop15/queue/iostats
echo "0" > /sys/fs/f2fs_dev/mmcblk0p79/iostat_enable
chmod 0644 /sys/devices/system/cpu/cpufreq/policy0/scaling_governor
chmod 0644 /sys/devices/system/cpu/cpufreq/policy6/scaling_governor
restorecon -R /sys/devices/system/cpu
echo "performance" > /sys/devices/system/cpu/cpufreq/policy0/scaling_governor
echo "performance" > /sys/devices/system/cpu/cpufreq/policy6/scaling_governor
echo '0' > /sys/devices/system/cpu/isolated
echo '0' > /sys/devices/system/cpu/offline
echo '0' > /sys/devices/system/cpu/uevent
echo '1' > /sys/devices/system/cpu/cpufreq/policy0/schedutil/iowait_boost_enable
echo '1' > /sys/devices/system/cpu/cpufreq/policy4/schedutil/iowait_boost_enable
echo '1' > /sys/devices/system/cpu/sched/cpu_prefer
chmod 0644 /sys/block/sda/queue/*
chmod 0644 /sys/block/sdb/queue/*
chmod 0644 /sys/block/sdc/queue/*
echo "noop" > /sys/block/mmcblk0/queue/scheduler
echo "noop" > /sys/block/mmcblk1/queue/scheduler
echo "noop" > /sys/block/sda/queue/scheduler
echo "noop" > /sys/block/sdb/queue/scheduler
echo "noop" > /sys/block/sdc/queue/scheduler
chmod 0444 /dev/stune/foreground/*
chmod 0444 /proc/cpufreq/*
echo '35' > /dev/stune/foreground/schedtune.boost
echo '1' > /proc/cpufreq/cpufreq_cci_mode
stop perfd
echo '0' > /sys/module/lowmemorykiller/parameters/enable_adaptive_lmk
echo '500' > /proc/sys/vm/vfs_cache_pressure
echo '99999' > /proc/sys/vm/extra_free_kbytes
echo '128' > /sys/block/mmcblk0/queue/read_ahead_kb
echo '128' > /sys/block/mmcblk1/queue/read_ahead_kb
echo '1024' > /sys/block/ram0/queue/read_ahead_kb
echo '1024' > /sys/block/ram1/queue/read_ahead_kb
echo '1024' > /sys/block/ram2/queue/read_ahead_kb
echo '1024' > /sys/block/ram3/queue/read_ahead_kb
echo '1024' > /sys/block/ram4/queue/read_ahead_kb
echo '1024' > /sys/block/ram5/queue/read_ahead_kb
echo '1024' > /sys/block/ram6/queue/read_ahead_kb
echo '1024' > /sys/block/ram7/queue/read_ahead_kb
echo '1024' > /sys/block/ram8/queue/read_ahead_kb
echo '1024' > /sys/block/ram9/queue/read_ahead_kb
echo '1024' > /sys/block/ram10/queue/read_ahead_kb
echo '1024' > /sys/block/ram11/queue/read_ahead_kb
echo '1024' > /sys/block/ram12/queue/read_ahead_kb
echo '1024' > /sys/block/ram13/queue/read_ahead_kb
echo '1024' > /sys/block/ram14/queue/read_ahead_kb
echo '1024' > /sys/block/ram15/queue/read_ahead_kb
echo '1024' > /sys/block/vnswap0/queue/read_ahead_kb
echo '0' > /sys/module/lowmemorykiller/parameters/enable_adaptive_lmk
echo '80' > /proc/sys/vm/overcommit_ratio
echo '400' > /proc/sys/vm/vfs_cache_pressure
echo '24300' > /proc/sys/vm/extra_free_kbytes
echo '512' > /proc/sys/kernel/random/read_wakeup_threshold
echo '1024' > /proc/sys/kernel/random/write_wakeup_threshold
echo '1024' > /sys/block/mmcblk0/queue/read_ahead_kb
echo '0' > /sys/block/mmcblk0/queue/iostats
echo '1' > /sys/block/mmcblk0/queue/add_random
echo '1024' > /sys/block/mmcblk1/queue/read_ahead_kb
echo '0' > /sys/block/mmcblk1/queue/iostats
echo '1' > /sys/block/mmcblk1/queue/add_random
echo '4096' > /proc/sys/vm/min_free_kbytes
echo '0' > /proc/sys/vm/oom_kill_allocating_task
echo '90' > /proc/sys/vm/dirty_ratio
echo '70' > /proc/sys/vm/dirty_background_ratio
chmod 666 /sys/module/lowmemorykiller/parameters/minfree
chown root /sys/module/lowmemorykiller/parameters/minfree
echo '21816,29088,36360,43632,50904,65448' > /sys/module/lowmemorykiller/parameters/minfree
rm /data/system/perfd/default_values
start perfd
for i in /sys/devices/system/cpu/cpu[0,4,7]/core_ctl ; do
chmod 666 $i/enable
echo 0 > $i/enable
chmod 444 $i/enable
done ;
exit 0
fstrim -v /cache
fstrim -v /system
fstrim -v /vendor
fstrim -v /data
fstrim -v /preload
